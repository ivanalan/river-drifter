
//{{BLOCK(river1)

//======================================================================
//
//	river1, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 58 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 1856 + 4096 = 6464
//
//	Time-stamp: 2019-11-17, 16:42:47
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_RIVER1_H
#define GRIT_RIVER1_H

#define river1TilesLen 1856
extern const unsigned short river1Tiles[928];

#define river1MapLen 4096
extern const unsigned short river1Map[2048];

#define river1PalLen 512
extern const unsigned short river1Pal[256];

#endif // GRIT_RIVER1_H

//}}BLOCK(river1)
